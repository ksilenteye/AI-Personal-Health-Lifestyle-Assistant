from fastapi.testclient import TestClient


def test_signup_and_login(client: TestClient):
    email = "test@example.com"
    password = "password123"

    r = client.post("/api/auth/signup", json={"email": email, "password": password})
    assert r.status_code == 200
    data = r.json()
    assert "access_token" in data

    r2 = client.post("/api/auth/login", json={"email": email, "password": password})
    assert r2.status_code == 200
    assert "access_token" in r2.json()


def test_profile_requires_auth(client: TestClient):
    r = client.get("/api/profile/me")
    assert r.status_code == 401

