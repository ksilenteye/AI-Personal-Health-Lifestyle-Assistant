from fastapi.testclient import TestClient


def _auth_header(client: TestClient, email: str, password: str) -> dict:
    r = client.post("/api/auth/signup", json={"email": email, "password": password})
    assert r.status_code == 200
    token = r.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}


def test_upsert_profile(client: TestClient):
    email = "profile@example.com"
    password = "password123"
    headers = _auth_header(client, email, password)

    payload = {
        "age": 30,
        "weight_kg": 70.0,
        "height_cm": 175.0,
        "gender": "male",
        "goal": "weight_loss",
        "body_type": "athletic",
    }

    r = client.put("/api/profile/me", json=payload, headers=headers)
    assert r.status_code == 200
    data = r.json()
    assert data["goal"] == "weight_loss"

    r2 = client.get("/api/profile/me", headers=headers)
    assert r2.status_code == 200
    assert r2.json()["age"] == 30

