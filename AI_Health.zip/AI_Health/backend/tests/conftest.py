import os
import pathlib
import pytest

from fastapi.testclient import TestClient


# Set env vars BEFORE importing app modules, because config/settings are read at import time.
TEST_DB_PATH = pathlib.Path(__file__).parent / "test.db"
os.environ["DATABASE_URL"] = f"sqlite+pysqlite:///{TEST_DB_PATH}"
os.environ["JWT_SECRET"] = "test_secret"
os.environ["JWT_EXPIRES_MIN"] = "60"
os.environ["CORS_ORIGINS"] = "http://localhost:3000"
os.environ["CREATE_TABLES_ON_STARTUP"] = "true"


@pytest.fixture()
def client():
    from app.main import create_app
    from app.core.database import Base, engine

    # Reset schema for a clean test run.
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)

    app = create_app()
    with TestClient(app) as c:
        yield c

