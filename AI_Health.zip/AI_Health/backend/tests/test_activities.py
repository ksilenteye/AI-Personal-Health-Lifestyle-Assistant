import datetime as dt

from fastapi.testclient import TestClient


def _headers(client: TestClient):
    email = "activity@example.com"
    password = "password123"
    r = client.post("/api/auth/signup", json={"email": email, "password": password})
    assert r.status_code == 200
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


def test_activity_upsert_and_recent(client: TestClient):
    headers = _headers(client)

    # profile is not required for activity upsert, but recommendation does.
    today = dt.date.today().isoformat()
    payload = {
        "activity_date": today,
        "steps": 8500,
        "calories_burned": 420,
        "distance_km": 6.5,
        "sleep_time": "23:30",
        "wake_up_time": "06:30",
    }
    r = client.post("/api/activities", json=payload, headers=headers)
    assert r.status_code == 200

    r2 = client.get("/api/activities/recent?days=7", headers=headers)
    assert r2.status_code == 200
    items = r2.json()
    assert isinstance(items, list)
    assert len(items) >= 1


def test_recommendations_today_requires_profile(client: TestClient):
    headers = _headers(client)
    today = dt.date.today().isoformat()
    # Without profile, recommendations should fail with 400.
    r = client.get(f"/api/recommendations/today?date={today}", headers=headers)
    assert r.status_code == 400

