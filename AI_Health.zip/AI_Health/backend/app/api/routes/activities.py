import datetime as dt

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, get_db
from app.schemas.activity import ActivityUpsertRequest, ActivityResponse
from app.services.activity_service import ActivityService

router = APIRouter()


@router.post("", response_model=ActivityResponse)
def upsert_activity(
    body: ActivityUpsertRequest,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
) -> ActivityResponse:
    activity = ActivityService.upsert_daily(db, user.id, body)
    return ActivityResponse(
        activity_date=activity.activity_date,
        steps=activity.steps,
        calories_burned=activity.calories_burned,
        distance_km=float(activity.distance_km),
        sleep_time=activity.sleep_time,
        wake_up_time=activity.wake_up_time,
    )


@router.get("/recent", response_model=list[ActivityResponse])
def recent(
    days: int = Query(default=7, ge=1, le=60),
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
) -> list[ActivityResponse]:
    items = ActivityService.recent(db, user.id, days)
    return [
        ActivityResponse(
            activity_date=a.activity_date,
            steps=a.steps,
            calories_burned=a.calories_burned,
            distance_km=float(a.distance_km),
            sleep_time=a.sleep_time,
            wake_up_time=a.wake_up_time,
        )
        for a in items
    ]

