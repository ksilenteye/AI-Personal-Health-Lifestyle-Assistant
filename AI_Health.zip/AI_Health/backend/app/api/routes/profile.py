from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, get_db
from app.schemas.profile import ProfileUpsertRequest, ProfileResponse
from app.services.profile_service import ProfileService

router = APIRouter()


@router.get("/me", response_model=ProfileResponse)
def get_me(
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
) -> ProfileResponse:
    profile = ProfileService.get_or_none(db, user.id)
    if profile is None:
        return ProfileResponse()
    return ProfileResponse(
        age=profile.age,
        weight_kg=float(profile.weight_kg) if profile.weight_kg is not None else None,
        height_cm=float(profile.height_cm) if profile.height_cm is not None else None,
        gender=profile.gender,  # validated in update
        goal=profile.goal if profile.goal else None,
        body_type=profile.body_type if profile.body_type else None,
    )


@router.put("/me", response_model=ProfileResponse)
def upsert_me(
    body: ProfileUpsertRequest,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
) -> ProfileResponse:
    profile = ProfileService.upsert(db, user.id, body)
    return ProfileResponse(
        age=profile.age,
        weight_kg=float(profile.weight_kg) if profile.weight_kg is not None else None,
        height_cm=float(profile.height_cm) if profile.height_cm is not None else None,
        gender=profile.gender,
        goal=profile.goal,
        body_type=profile.body_type,
    )

