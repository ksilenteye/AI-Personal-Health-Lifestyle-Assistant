import datetime as dt

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, get_db
from app.schemas.recommendation import RecommendationResponse
from app.services.recommendation_service import RecommendationService

router = APIRouter()


@router.get("/today", response_model=RecommendationResponse)
def today(
    date: dt.date | None = Query(default=None),
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
) -> RecommendationResponse:
    target_date = date or dt.date.today()
    try:
        return RecommendationService.today(db=db, user_id=user.id, date=target_date)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e

