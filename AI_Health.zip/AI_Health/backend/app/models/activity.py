import uuid
import datetime as dt
from datetime import timezone

from sqlalchemy import Date, ForeignKey, Integer, Numeric, Time, DateTime, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy import Uuid

from app.core.database import Base


class Activity(Base):
    __tablename__ = "activities"

    id: Mapped[uuid.UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id: Mapped[uuid.UUID] = mapped_column(Uuid(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)

    activity_date: Mapped[dt.date] = mapped_column(Date, nullable=False, index=True)
    steps: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    calories_burned: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    distance_km: Mapped[float] = mapped_column(Numeric(6, 2), nullable=False, default=0)

    sleep_time: Mapped[dt.time | None] = mapped_column(Time, nullable=True)
    wake_up_time: Mapped[dt.time | None] = mapped_column(Time, nullable=True)

    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=lambda: dt.datetime.now(timezone.utc), nullable=False)

    # enforce one row per day per user
    # enforce one row per day per user
    __table_args__ = (
        UniqueConstraint("user_id", "activity_date", name="uq_user_activity_date"),
    )

