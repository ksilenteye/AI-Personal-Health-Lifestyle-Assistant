from sqlalchemy.orm import Session
from sqlalchemy import select

from app.models.profile import Profile
from app.schemas.profile import ProfileUpsertRequest


class ProfileService:
    @staticmethod
    def get_or_none(db: Session, user_id) -> Profile | None:
        return db.scalar(select(Profile).where(Profile.user_id == user_id))

    @staticmethod
    def upsert(db: Session, user_id, body: ProfileUpsertRequest) -> Profile:
        existing = ProfileService.get_or_none(db, user_id)
        if existing is None:
            profile = Profile(
                user_id=user_id,
                age=body.age,
                weight_kg=body.weight_kg,
                height_cm=body.height_cm,
                gender=body.gender,
                goal=body.goal,
                body_type=body.body_type,
            )
            db.add(profile)
            db.commit()
            db.refresh(profile)
            return profile

        existing.age = body.age
        existing.weight_kg = body.weight_kg
        existing.height_cm = body.height_cm
        existing.gender = body.gender
        existing.goal = body.goal
        existing.body_type = body.body_type
        db.commit()
        db.refresh(existing)
        return existing

