import datetime as dt

from sqlalchemy.orm import Session

from app.models.profile import Profile
from app.models.activity import Activity
from app.schemas.recommendation import RecommendationResponse, WorkoutSuggestion, DietSuggestion
from app.utils.nutrition import maintenance_calories, macros_for_goal
from app.utils.time import sleep_hours
from app.utils.workouts import suggested_workout


class RecommendationService:
    @staticmethod
    def today(
        db: Session,
        user_id,
        date: dt.date,
    ) -> RecommendationResponse:
        profile = db.query(Profile).filter(Profile.user_id == user_id).one_or_none()
        if profile is None:
            raise ValueError("Profile not found")

        activity = db.query(Activity).filter(Activity.user_id == user_id, Activity.activity_date == date).one_or_none()
        if activity is None:
            # allow recommendation without activity; assume steps 0 and no sleep times
            activity = Activity(
                user_id=user_id,
                activity_date=date,
                steps=0,
                calories_burned=0,
                distance_km=0,
                sleep_time=None,
                wake_up_time=None,
            )

        if profile.age is None or profile.weight_kg is None or profile.height_cm is None:
            raise ValueError("Profile is incomplete")

        base_maintenance = maintenance_calories(
            age=int(profile.age),
            weight_kg=float(profile.weight_kg),
            height_cm=float(profile.height_cm),
            gender=profile.gender,
            steps=int(activity.steps),
        )

        goal = profile.goal
        if goal == "weight_loss":
            calorie_target = int(base_maintenance - 500)
        elif goal == "weight_gain":
            calorie_target = int(base_maintenance + 300)
        else:
            calorie_target = int(base_maintenance)

        # Ensure not wildly negative.
        calorie_target = max(calorie_target, 1200)

        sh = sleep_hours(activity.sleep_time, activity.wake_up_time)
        workout = suggested_workout(goal=profile.goal, body_type=profile.body_type, sleep_hours=sh, steps=int(activity.steps))

        diet = DietSuggestion(
            calorie_target=calorie_target,
            macros=macros_for_goal(goal=profile.goal, weight_kg=float(profile.weight_kg), calorie_target=calorie_target),
            notes=[],
        )

        return RecommendationResponse(
            date=date,
            calorie_target=calorie_target,
            workout_suggestion=WorkoutSuggestion(**workout),
            diet_suggestion=diet,
            notes=workout.get("notes", []),
        )

