import datetime as dt

from sqlalchemy.orm import Session
from sqlalchemy import select, and_

from app.models.activity import Activity
from app.schemas.activity import ActivityUpsertRequest


class ActivityService:
    @staticmethod
    def upsert_daily(db: Session, user_id, body: ActivityUpsertRequest) -> Activity:
        q = select(Activity).where(and_(Activity.user_id == user_id, Activity.activity_date == body.activity_date))
        existing = db.scalar(q)

        if existing is None:
            activity = Activity(
                user_id=user_id,
                activity_date=body.activity_date,
                steps=body.steps,
                calories_burned=body.calories_burned,
                distance_km=body.distance_km,
                sleep_time=body.sleep_time,
                wake_up_time=body.wake_up_time,
            )
            db.add(activity)
            db.commit()
            db.refresh(activity)
            return activity

        existing.steps = body.steps
        existing.calories_burned = body.calories_burned
        existing.distance_km = body.distance_km
        existing.sleep_time = body.sleep_time
        existing.wake_up_time = body.wake_up_time
        db.commit()
        db.refresh(existing)
        return existing

    @staticmethod
    def recent(db: Session, user_id, days: int) -> list[Activity]:
        start_date = dt.date.today() - dt.timedelta(days=days)
        q = (
            select(Activity)
            .where(and_(Activity.user_id == user_id, Activity.activity_date >= start_date))
            .order_by(Activity.activity_date.desc())
        )
        return list(db.scalars(q).all())

