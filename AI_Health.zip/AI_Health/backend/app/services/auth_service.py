from sqlalchemy.orm import Session
from sqlalchemy import select

from app.core.security import create_access_token, hash_password, verify_password
from app.models.user import User


class AuthService:
    @staticmethod
    def signup(db: Session, email: str, password: str) -> str:
        existing = db.scalar(select(User).where(User.email == email))
        if existing:
            raise ValueError("Email already registered")

        user = User(email=email, password_hash=hash_password(password))
        db.add(user)
        db.commit()
        db.refresh(user)
        return create_access_token(str(user.id))

    @staticmethod
    def login(db: Session, email: str, password: str) -> str:
        user = db.scalar(select(User).where(User.email == email))
        if not user or not verify_password(password, user.password_hash):
            raise ValueError("Invalid credentials")
        return create_access_token(str(user.id))

