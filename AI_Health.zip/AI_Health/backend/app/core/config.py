from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    DATABASE_URL: str
    JWT_SECRET: str
    JWT_EXPIRES_MIN: int = 60

    # Comma-separated origins, e.g. "http://localhost:3000,http://localhost:5173"
    CORS_ORIGINS: str = "http://localhost:3000"
    CREATE_TABLES_ON_STARTUP: bool = True

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


settings = Settings()
