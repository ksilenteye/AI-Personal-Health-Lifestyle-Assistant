from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase
from app.core.config import settings

engine = create_engine(settings.DATABASE_URL, pool_pre_ping=True, future=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


class Base(DeclarativeBase):
    pass


def init_db() -> None:
    """
    MVP convenience:
    - In production you should use Alembic migrations.
    - For demo, we can create tables at startup.
    """
    if not settings.CREATE_TABLES_ON_STARTUP:
        return
    from app.models import user, profile, activity  # noqa: F401
    Base.metadata.create_all(bind=engine)
