import datetime as dt


def sleep_hours(sleep_time: dt.time | None, wake_up_time: dt.time | None) -> float | None:
    """
    Returns hours slept if both times are provided.
    Assumes wake-up may occur after midnight.
    """
    if sleep_time is None or wake_up_time is None:
        return None

    # Use an arbitrary date; handle crossing midnight.
    sleep_dt = dt.datetime(2000, 1, 1, sleep_time.hour, sleep_time.minute)
    wake_dt = dt.datetime(2000, 1, 1, wake_up_time.hour, wake_up_time.minute)
    if wake_dt <= sleep_dt:
        wake_dt = wake_dt + dt.timedelta(days=1)
    delta = wake_dt - sleep_dt
    return delta.total_seconds() / 3600.0

