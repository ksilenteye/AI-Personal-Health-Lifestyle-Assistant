import datetime as dt


def activity_factor_from_steps(steps: int) -> float:
    if steps < 5000:
        return 1.2
    if steps < 7500:
        return 1.375
    if steps < 10000:
        return 1.55
    return 1.725


def mifflin_st_jeor_bmr(age: int, weight_kg: float, height_cm: float, gender: str | None) -> float:
    """
    BMR = 10W + 6.25H - 5A + s
    s=+5 male, s=-161 female, s=0 other/unknown
    """
    g = (gender or "").lower()
    if g == "male":
        s = 5
    elif g == "female":
        s = -161
    else:
        s = 0
    return 10 * weight_kg + 6.25 * height_cm - 5 * age + s


def maintenance_calories(age: int, weight_kg: float, height_cm: float, gender: str | None, steps: int) -> float:
    bmr = mifflin_st_jeor_bmr(age=age, weight_kg=weight_kg, height_cm=height_cm, gender=gender)
    factor = activity_factor_from_steps(steps)
    return bmr * factor


def macros_for_goal(goal: str, weight_kg: float, calorie_target: int) -> dict[str, float]:
    """
    Very simple macro heuristic:
    - protein (g) based on kg
    - fat (g) based on kg
    - carbs fill remaining calories
    """
    g = (goal or "").lower()
    if g == "weight_gain":
        protein_g = 1.6 * weight_kg
        fat_g = 0.7 * weight_kg
    elif g == "weight_loss":
        protein_g = 1.8 * weight_kg
        fat_g = 0.8 * weight_kg
    else:  # maintenance
        protein_g = 1.5 * weight_kg
        fat_g = 0.75 * weight_kg

    protein_cal = protein_g * 4
    fat_cal = fat_g * 9
    remaining = max(calorie_target - int(protein_cal + fat_cal), 0)
    carbs_g = remaining / 4
    return {"protein_g": round(protein_g, 1), "carbs_g": round(carbs_g, 1), "fat_g": round(fat_g, 1)}

