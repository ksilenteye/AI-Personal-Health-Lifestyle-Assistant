def suggested_workout(goal: str, body_type: str, sleep_hours: float | None, steps: int) -> dict:
    """
    Rule-based workout planner for Phase 1.
    """
    g = (goal or "").lower()
    bt = (body_type or "").lower()

    intensity = "medium"
    if g == "weight_loss":
        workout_type = "hybrid"
        intensity = "high"
    elif g == "weight_gain":
        workout_type = "strength"
        intensity = "high"
    else:
        workout_type = "hybrid"
        intensity = "medium"

    # If sleep is poor, reduce intensity.
    if sleep_hours is not None and sleep_hours < 6:
        intensity = "low" if intensity == "high" else "medium"

    # Gentle adjustment based on steps (cardio readiness).
    if steps < 5000 and workout_type in {"hybrid", "cardio"}:
        workout_type = "mobility" if bt == "lean" else "hybrid"

    duration_min = 35 if intensity == "low" else 50 if intensity == "medium" else 60

    notes = []
    if sleep_hours is not None and sleep_hours < 6:
        notes.append("Sleep is below 6 hours; reduce intensity and focus on form.")
    if g == "weight_loss":
        notes.append("Include intervals or finishing cardio to support deficit.")
    if g == "weight_gain":
        notes.append("Prioritize progressive overload and adequate recovery.")

    return {
        "type": workout_type,
        "intensity": intensity,
        "duration_min": duration_min,
        "notes": notes,
    }

