import datetime as dt
from typing import Literal

from pydantic import BaseModel


class WorkoutSuggestion(BaseModel):
    type: Literal["cardio", "strength", "hybrid", "mobility"]
    intensity: Literal["low", "medium", "high"]
    duration_min: int
    notes: list[str] = []


class DietSuggestion(BaseModel):
    calorie_target: int
    macros: dict[str, float]  # protein_g, carbs_g, fat_g
    notes: list[str] = []


class RecommendationResponse(BaseModel):
    date: dt.date
    calorie_target: int
    workout_suggestion: WorkoutSuggestion
    diet_suggestion: DietSuggestion
    notes: list[str] = []

