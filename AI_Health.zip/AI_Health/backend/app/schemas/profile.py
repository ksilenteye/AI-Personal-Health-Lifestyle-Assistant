from typing import Literal

from pydantic import BaseModel, Field, conint, confloat


Gender = Literal["male", "female", "other"]
Goal = Literal["weight_loss", "weight_gain", "maintenance"]
BodyType = Literal["lean", "athletic", "bulky"]


class ProfileUpsertRequest(BaseModel):
    age: conint(ge=13, le=120)
    weight_kg: confloat(gt=20, lt=300)
    height_cm: confloat(gt=120, lt=230)
    gender: Gender
    goal: Goal
    body_type: BodyType


class ProfileResponse(BaseModel):
    age: int | None = None
    weight_kg: float | None = None
    height_cm: float | None = None
    gender: Gender | None = None
    goal: Goal | None = None
    body_type: BodyType | None = None

    class Config:
        from_attributes = True

