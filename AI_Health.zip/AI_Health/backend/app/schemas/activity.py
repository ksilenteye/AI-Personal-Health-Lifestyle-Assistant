import datetime as dt

from pydantic import BaseModel, Field, conint, confloat


class ActivityUpsertRequest(BaseModel):
    activity_date: dt.date
    steps: conint(ge=0, le=100000) = 0
    calories_burned: conint(ge=0, le=20000) = 0
    distance_km: confloat(ge=0, le=200) = 0
    sleep_time: dt.time | None = None  # local time
    wake_up_time: dt.time | None = None  # local time


class ActivityResponse(BaseModel):
    activity_date: dt.date
    steps: int
    calories_burned: int
    distance_km: float
    sleep_time: dt.time | None
    wake_up_time: dt.time | None

    class Config:
        from_attributes = True

