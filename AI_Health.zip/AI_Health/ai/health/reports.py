"""
Phase 3 placeholder for health report parsing (OCR).
"""


def parse_health_report(*args, **kwargs):
    raise NotImplementedError("Health report parsing not implemented yet")

