"""
Phase 3/4 placeholder.

When ML-based recommendation is introduced, this module can be used as the
stable interface for strategy selection and rule fallback.
"""


def recommend_calories_and_workout(*args, **kwargs):
    raise NotImplementedError("AI recommendation engine not implemented yet")

