"""
Phase 3 placeholder for the LLM-based AI coach.

Later you can implement an adapter class that streams or returns coaching
messages based on user state and recommendation inputs.
"""


def generate_coaching_reply(*args, **kwargs) -> str:
    raise NotImplementedError("LLM coach not implemented yet")

