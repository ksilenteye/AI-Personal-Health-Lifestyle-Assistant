"use client";

import { create } from "zustand";

type SessionState = {
  token: string | null;
  hydrate: () => void;
  setToken: (token: string | null) => void;
  logout: () => void;
};

export const useSessionStore = create<SessionState>((set) => ({
  token: null,
  hydrate: () => {
    try {
      const v = window.localStorage.getItem("token");
      set({ token: v });
    } catch {
      // ignore storage errors
    }
  },
  setToken: (token) => {
    try {
      if (token) window.localStorage.setItem("token", token);
      else window.localStorage.removeItem("token");
    } catch {
      // ignore storage errors
    }
    set({ token });
  },
  logout: () => {
    try {
      window.localStorage.removeItem("token");
    } catch {
      // ignore storage errors
    }
    set({ token: null });
  },
}));

