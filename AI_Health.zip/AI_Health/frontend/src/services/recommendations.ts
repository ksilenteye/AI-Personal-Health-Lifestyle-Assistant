"use client";

import { apiFetch } from "./api";

export type WorkoutSuggestion = {
  type: "cardio" | "strength" | "hybrid" | "mobility";
  intensity: "low" | "medium" | "high";
  duration_min: number;
  notes: string[];
};

export type DietSuggestion = {
  calorie_target: number;
  macros: { protein_g: number; carbs_g: number; fat_g: number };
  notes: string[];
};

export type RecommendationResponse = {
  date: string;
  calorie_target: number;
  workout_suggestion: WorkoutSuggestion;
  diet_suggestion: DietSuggestion;
  notes: string[];
};

export async function getTodayRecommendations(date?: string): Promise<RecommendationResponse> {
  const qs = new URLSearchParams();
  if (date) qs.set("date", date);
  const path = qs.toString().length ? `/api/recommendations/today?${qs.toString()}` : "/api/recommendations/today";
  return apiFetch<RecommendationResponse>(path);
}

