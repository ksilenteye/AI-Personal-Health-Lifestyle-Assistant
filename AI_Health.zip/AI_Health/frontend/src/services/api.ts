"use client";

import { useSessionStore } from "../store/session";

const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:8000";

export async function apiFetch<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = useSessionStore.getState().token;

  const headers = new Headers(options.headers);
  headers.set("Content-Type", "application/json");
  if (token) headers.set("Authorization", `Bearer ${token}`);

  const res = await fetch(`${baseUrl}${path}`, {
    ...options,
    headers,
  });

  if (!res.ok) {
    let detail: string | undefined;
    try {
      const json = await res.json();
      detail = json?.detail;
    } catch {
      // ignore
    }
    throw new Error(detail || `Request failed with status ${res.status}`);
  }

  return (await res.json()) as T;
}

