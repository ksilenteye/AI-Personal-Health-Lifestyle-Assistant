"use client";

import { apiFetch } from "./api";

export type Activity = {
  activity_date: string;
  steps: number;
  calories_burned: number;
  distance_km: number;
  sleep_time: string | null;
  wake_up_time: string | null;
};

export type ActivityUpsertRequest = {
  activity_date: string; // YYYY-MM-DD
  steps: number;
  calories_burned: number;
  distance_km: number;
  sleep_time: string | null; // HH:MM
  wake_up_time: string | null; // HH:MM
};

export async function upsertActivity(body: ActivityUpsertRequest): Promise<Activity> {
  return apiFetch<Activity>("/api/activities", {
    method: "POST",
    body: JSON.stringify(body),
  });
}

export async function getRecentActivities(days: number): Promise<Activity[]> {
  const qs = new URLSearchParams({ days: String(days) });
  return apiFetch<Activity[]>(`/api/activities/recent?${qs.toString()}`);
}

