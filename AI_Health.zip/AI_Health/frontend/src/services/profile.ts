"use client";

import { apiFetch } from "./api";

export type Profile = {
  age: number | null;
  weight_kg: number | null;
  height_cm: number | null;
  gender: "male" | "female" | "other" | null;
  goal: "weight_loss" | "weight_gain" | "maintenance" | null;
  body_type: "lean" | "athletic" | "bulky" | null;
};

export type ProfileUpsertRequest = {
  age: number;
  weight_kg: number;
  height_cm: number;
  gender: "male" | "female" | "other";
  goal: "weight_loss" | "weight_gain" | "maintenance";
  body_type: "lean" | "athletic" | "bulky";
};

export async function getMyProfile(): Promise<Profile> {
  return apiFetch<Profile>("/api/profile/me");
}

export async function upsertMyProfile(body: ProfileUpsertRequest): Promise<Profile> {
  return apiFetch<Profile>("/api/profile/me", {
    method: "PUT",
    body: JSON.stringify(body),
  });
}

