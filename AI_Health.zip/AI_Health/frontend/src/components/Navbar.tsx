"use client";

import Link from "next/link";
import { useSessionStore } from "../store/session";

export default function Navbar() {
  const token = useSessionStore((s) => s.token);
  const logout = useSessionStore((s) => s.logout);

  return (
    <nav className="border-b border-gray-200 bg-white">
      <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3">
        <div className="text-sm font-semibold text-gray-900">AI Health Assistant</div>
        <div className="flex items-center gap-4 text-sm">
          {token ? (
            <>
              <Link className="text-gray-700 hover:text-gray-900" href="/dashboard">
                Dashboard
              </Link>
              <Link className="text-gray-700 hover:text-gray-900" href="/profile">
                Profile
              </Link>
              <button
                className="rounded bg-gray-900 px-3 py-1.5 text-white hover:bg-gray-800"
                onClick={() => logout()}
              >
                Logout
              </button>
            </>
          ) : (
            <Link className="text-gray-700 hover:text-gray-900" href="/login">
              Login
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}

