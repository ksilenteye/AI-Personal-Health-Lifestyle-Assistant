"use client";

import { useState, type FormEvent } from "react";
import { upsertActivity, type ActivityUpsertRequest } from "../../services/activities";

type Props = {
  defaultDate?: string; // YYYY-MM-DD
};

export default function ActivityForm({ defaultDate }: Props) {
  const [form, setForm] = useState<ActivityUpsertRequest>({
    activity_date: defaultDate ?? new Date().toISOString().slice(0, 10),
    steps: 0,
    calories_burned: 0,
    distance_km: 0,
    sleep_time: null,
    wake_up_time: null,
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSaved(false);
    try {
      await upsertActivity(form);
      setSaved(true);
    } catch (err: any) {
      setError(err?.message || "Failed to save activity");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      {error ? <div className="rounded border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</div> : null}
      {saved ? <div className="rounded border border-green-200 bg-green-50 p-3 text-sm text-green-700">Saved.</div> : null}

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <label className="block">
          <div className="text-sm text-gray-600">Date</div>
          <input
            type="date"
            className="mt-1 w-full rounded border border-gray-200 p-2"
            value={form.activity_date}
            onChange={(e) => setForm((p) => ({ ...p, activity_date: e.target.value }))}
          />
        </label>
        <label className="block">
          <div className="text-sm text-gray-600">Steps</div>
          <input
            type="number"
            className="mt-1 w-full rounded border border-gray-200 p-2"
            value={form.steps}
            onChange={(e) => setForm((p) => ({ ...p, steps: Number(e.target.value) }))}
          />
        </label>
        <label className="block">
          <div className="text-sm text-gray-600">Calories Burned</div>
          <input
            type="number"
            className="mt-1 w-full rounded border border-gray-200 p-2"
            value={form.calories_burned}
            onChange={(e) => setForm((p) => ({ ...p, calories_burned: Number(e.target.value) }))}
          />
        </label>
        <label className="block">
          <div className="text-sm text-gray-600">Distance (km)</div>
          <input
            type="number"
            step="0.1"
            className="mt-1 w-full rounded border border-gray-200 p-2"
            value={form.distance_km}
            onChange={(e) => setForm((p) => ({ ...p, distance_km: Number(e.target.value) }))}
          />
        </label>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <label className="block">
          <div className="text-sm text-gray-600">Sleep Time</div>
          <input
            type="time"
            className="mt-1 w-full rounded border border-gray-200 p-2"
            value={form.sleep_time ?? ""}
            onChange={(e) => setForm((p) => ({ ...p, sleep_time: e.target.value || null }))}
          />
        </label>
        <label className="block">
          <div className="text-sm text-gray-600">Wake Up Time</div>
          <input
            type="time"
            className="mt-1 w-full rounded border border-gray-200 p-2"
            value={form.wake_up_time ?? ""}
            onChange={(e) => setForm((p) => ({ ...p, wake_up_time: e.target.value || null }))}
          />
        </label>
      </div>

      <button
        type="submit"
        disabled={loading}
        className="w-full rounded bg-gray-900 px-4 py-2 text-white hover:bg-gray-800 disabled:bg-gray-400"
      >
        {loading ? "Saving..." : "Save Activity"}
      </button>
    </form>
  );
}

