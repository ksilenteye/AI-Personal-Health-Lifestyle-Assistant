"use client";

import { useEffect, useMemo, useState, type FormEvent } from "react";
import { upsertMyProfile, type Profile, type ProfileUpsertRequest } from "../../services/profile";

type Props = {
  initial?: Profile | null;
};

export default function ProfileForm({ initial }: Props) {
  const [form, setForm] = useState<ProfileUpsertRequest>({
    age: 25,
    weight_kg: 70,
    height_cm: 175,
    gender: "male",
    goal: "weight_loss",
    body_type: "athletic",
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (!initial) return;
    setForm((prev) => ({
      ...prev,
      age: initial.age ?? prev.age,
      weight_kg: initial.weight_kg ?? prev.weight_kg,
      height_cm: initial.height_cm ?? prev.height_cm,
      gender: (initial.gender ?? prev.gender) as ProfileUpsertRequest["gender"],
      goal: (initial.goal ?? prev.goal) as ProfileUpsertRequest["goal"],
      body_type: (initial.body_type ?? prev.body_type) as ProfileUpsertRequest["body_type"],
    }));
  }, [initial]);

  const canSubmit = useMemo(() => {
    return form.age > 0 && form.weight_kg > 0 && form.height_cm > 0 && !!form.goal && !!form.body_type;
  }, [form]);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSaved(false);
    try {
      await upsertMyProfile(form);
      setSaved(true);
    } catch (err: any) {
      setError(err?.message || "Failed to save profile");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      {error ? <div className="rounded border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</div> : null}
      {saved ? <div className="rounded border border-green-200 bg-green-50 p-3 text-sm text-green-700">Saved.</div> : null}

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <label className="block">
          <div className="text-sm text-gray-600">Age</div>
          <input
            type="number"
            className="mt-1 w-full rounded border border-gray-200 p-2"
            value={form.age}
            onChange={(e) => setForm((p) => ({ ...p, age: Number(e.target.value) }))}
          />
        </label>
        <label className="block">
          <div className="text-sm text-gray-600">Weight (kg)</div>
          <input
            type="number"
            className="mt-1 w-full rounded border border-gray-200 p-2"
            value={form.weight_kg}
            step="0.1"
            onChange={(e) => setForm((p) => ({ ...p, weight_kg: Number(e.target.value) }))}
          />
        </label>
        <label className="block">
          <div className="text-sm text-gray-600">Height (cm)</div>
          <input
            type="number"
            className="mt-1 w-full rounded border border-gray-200 p-2"
            value={form.height_cm}
            step="0.1"
            onChange={(e) => setForm((p) => ({ ...p, height_cm: Number(e.target.value) }))}
          />
        </label>
        <label className="block">
          <div className="text-sm text-gray-600">Gender</div>
          <select
            className="mt-1 w-full rounded border border-gray-200 p-2"
            value={form.gender}
            onChange={(e) => setForm((p) => ({ ...p, gender: e.target.value as ProfileUpsertRequest["gender"] }))}
          >
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
          </select>
        </label>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <label className="block">
          <div className="text-sm text-gray-600">Goal</div>
          <select
            className="mt-1 w-full rounded border border-gray-200 p-2"
            value={form.goal}
            onChange={(e) => setForm((p) => ({ ...p, goal: e.target.value as ProfileUpsertRequest["goal"] }))}
          >
            <option value="weight_loss">Weight loss</option>
            <option value="weight_gain">Weight gain</option>
            <option value="maintenance">Maintenance</option>
          </select>
        </label>

        <label className="block">
          <div className="text-sm text-gray-600">Body Type</div>
          <select
            className="mt-1 w-full rounded border border-gray-200 p-2"
            value={form.body_type}
            onChange={(e) => setForm((p) => ({ ...p, body_type: e.target.value as ProfileUpsertRequest["body_type"] }))}
          >
            <option value="lean">Lean</option>
            <option value="athletic">Athletic</option>
            <option value="bulky">Bulky</option>
          </select>
        </label>
      </div>

      <button
        type="submit"
        disabled={!canSubmit || loading}
        className="w-full rounded bg-gray-900 px-4 py-2 text-white hover:bg-gray-800 disabled:bg-gray-400"
      >
        {loading ? "Saving..." : "Save Profile"}
      </button>
    </form>
  );
}

