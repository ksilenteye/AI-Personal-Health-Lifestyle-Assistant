import Link from "next/link";

export default function HomePage() {
  return (
    <div className="space-y-3">
      <h1 className="text-2xl font-semibold">AI Health Assistant</h1>
      <p className="text-gray-600">Sign in to track activity, sleep, and get recommendations.</p>
      <Link className="inline-block rounded bg-gray-900 px-4 py-2 text-white hover:bg-gray-800" href="/login">
        Go to Login
      </Link>
    </div>
  );
}

