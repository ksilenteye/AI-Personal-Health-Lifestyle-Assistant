"use client";

export default function WorkoutPage() {
  return (
    <div className="space-y-3">
      <h1 className="text-2xl font-semibold">Workouts</h1>
      <div className="text-sm text-gray-600">Phase 2: gym equipment-based workout planner.</div>
    </div>
  );
}

