"use client";

export default function SchedulePage() {
  return (
    <div className="space-y-3">
      <h1 className="text-2xl font-semibold">Schedule</h1>
      <div className="text-sm text-gray-600">Phase 2: smart schedules and notifications.</div>
    </div>
  );
}

