"use client";

import { useEffect, useState } from "react";
import ActivityForm from "../../src/components/Forms/ActivityForm";
import { useSessionStore } from "../../src/store/session";

export default function ActivityPage() {
  const token = useSessionStore((s) => s.token);
  const hydrate = useSessionStore((s) => s.hydrate);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  useEffect(() => {
    if (!token) setError("Please login first.");
    else setError(null);
  }, [token]);

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Daily Activity</h1>
      {error ? <div className="rounded border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</div> : null}
      {token ? <ActivityForm /> : null}
    </div>
  );
}

