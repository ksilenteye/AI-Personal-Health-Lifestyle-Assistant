"use client";

import { useEffect, useMemo, useState } from "react";
import StatCard from "../../src/components/StatCard";
import { useSessionStore } from "../../src/store/session";
import { getMyProfile, type Profile } from "../../src/services/profile";
import { getRecentActivities, type Activity } from "../../src/services/activities";
import { getTodayRecommendations, type RecommendationResponse } from "../../src/services/recommendations";

export default function DashboardPage() {
  const token = useSessionStore((s) => s.token);
  const hydrate = useSessionStore((s) => s.hydrate);

  const [profile, setProfile] = useState<Profile | null>(null);
  const [recent, setRecent] = useState<Activity[]>([]);
  const [reco, setReco] = useState<RecommendationResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const todayStr = useMemo(() => new Date().toISOString().slice(0, 10), []);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  useEffect(() => {
    if (!token) {
      setLoading(false);
      setError("Please login first.");
      return;
    }

    async function load() {
      setLoading(true);
      setError(null);
      try {
        const [p, r, rec] = await Promise.all([
          getMyProfile(),
          getRecentActivities(7),
          getTodayRecommendations(todayStr),
        ]);
        setProfile(p);
        setRecent(r);
        setReco(rec);
      } catch (err: any) {
        setError(err?.message || "Failed to load dashboard");
      } finally {
        setLoading(false);
      }
    }

    load();
  }, [token, todayStr]);

  if (loading) return <div>Loading...</div>;

  if (error) {
    return (
      <div className="space-y-2">
        <div className="rounded border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</div>
        <a className="text-sm text-gray-700 underline" href="/login">
          Go to login
        </a>
      </div>
    );
  }

  const sleepInfo =
    recent[0]?.sleep_time && recent[0]?.wake_up_time ? `${recent[0].sleep_time} - ${recent[0].wake_up_time}` : "Not set";

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Today Dashboard</h1>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <StatCard label="Steps (latest)" value={String(recent[0]?.steps ?? 0)} subtext={recent[0]?.activity_date ?? ""} />
        <StatCard label="Sleep (latest)" value={sleepInfo} />
        <StatCard label="Calorie Target" value={String(reco?.calorie_target ?? "-")} subtext={reco ? "AI rule-based" : ""} />
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <div className="rounded border border-gray-200 bg-white p-4">
          <div className="text-sm font-medium text-gray-700">Workout Suggestion</div>
          {reco ? (
            <div className="mt-2">
              <div className="text-2xl font-semibold text-gray-900">{reco.workout_suggestion.type}</div>
              <div className="mt-1 text-sm text-gray-600">Intensity: {reco.workout_suggestion.intensity}</div>
              <div className="mt-1 text-sm text-gray-600">Duration: {reco.workout_suggestion.duration_min} min</div>
              {reco.workout_suggestion.notes?.length ? (
                <div className="mt-3 space-y-1 text-sm text-gray-600">
                  {reco.workout_suggestion.notes.map((n, i) => (
                    <div key={i}>• {n}</div>
                  ))}
                </div>
              ) : null}
            </div>
          ) : (
            <div className="mt-2 text-sm text-gray-600">No recommendations yet.</div>
          )}
        </div>

        <div className="rounded border border-gray-200 bg-white p-4">
          <div className="text-sm font-medium text-gray-700">Diet Suggestion</div>
          {reco ? (
            <div className="mt-2">
              <div className="text-2xl font-semibold text-gray-900">{reco.diet_suggestion.calorie_target} kcal</div>
              <div className="mt-1 text-sm text-gray-600">
                Protein: {reco.diet_suggestion.macros.protein_g}g, Carbs: {reco.diet_suggestion.macros.carbs_g}g, Fat:{" "}
                {reco.diet_suggestion.macros.fat_g}g
              </div>
              {reco.diet_suggestion.notes?.length ? (
                <div className="mt-3 space-y-1 text-sm text-gray-600">
                  {reco.diet_suggestion.notes.map((n, i) => (
                    <div key={i}>• {n}</div>
                  ))}
                </div>
              ) : null}
            </div>
          ) : (
            <div className="mt-2 text-sm text-gray-600">No recommendations yet.</div>
          )}
        </div>
      </div>

      <div className="rounded border border-gray-200 bg-white p-4">
        <div className="text-sm font-medium text-gray-700">Recent Activities</div>
        <div className="mt-2 space-y-2">
          {recent.map((a) => (
            <div key={a.activity_date} className="flex items-center justify-between rounded bg-gray-50 px-3 py-2 text-sm">
              <div>
                <div className="font-medium text-gray-900">{a.activity_date}</div>
                <div className="text-gray-600">
                  Steps: {a.steps} • Sleep: {a.sleep_time && a.wake_up_time ? `${a.sleep_time}-${a.wake_up_time}` : "N/A"}
                </div>
              </div>
              <div className="text-right text-gray-700">
                {a.distance_km ? `${a.distance_km} km` : ""}
                <div className="text-xs text-gray-500">{a.calories_burned} kcal burned</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

