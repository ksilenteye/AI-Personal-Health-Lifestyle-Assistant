"use client";

export default function AICoachPage() {
  return (
    <div className="space-y-3">
      <h1 className="text-2xl font-semibold">AI Coach</h1>
      <div className="text-sm text-gray-600">Phase 3: LLM-based coaching chat.</div>
      <div className="rounded border border-gray-200 bg-white p-4 text-sm text-gray-600">
        This page is stubbed for now. The backend and UI structure are ready for integration.
      </div>
    </div>
  );
}

