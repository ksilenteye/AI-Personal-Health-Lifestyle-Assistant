"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { login } from "../../src/services/auth";
import { useSessionStore } from "../../src/store/session";
import type { FormEvent } from "react";

export default function LoginPage() {
  const router = useRouter();
  const token = useSessionStore((s) => s.token);
  const hydrate = useSessionStore((s) => s.hydrate);
  const setToken = useSessionStore((s) => s.setToken);

  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("user@example.com");
  const [password, setPassword] = useState("password123");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  useEffect(() => {
    if (token) router.push("/dashboard");
  }, [token, router]);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await (mode === "login"
        ? login(email, password)
        : // signup mode
          (await import("../../src/services/auth")).signup(email, password));
      setToken(res.access_token);
      router.push("/dashboard");
    } catch (err: any) {
      setError(err?.message || "Authentication failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-md space-y-4">
      <h1 className="text-2xl font-semibold">{mode === "login" ? "Login" : "Signup"}</h1>

      {error ? <div className="rounded border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</div> : null}

      <div className="flex gap-2 text-sm">
        <button
          className={`rounded border px-3 py-1 ${mode === "login" ? "bg-gray-900 text-white" : "bg-white text-gray-700"}`}
          onClick={() => setMode("login")}
          type="button"
        >
          Login
        </button>
        <button
          className={`rounded border px-3 py-1 ${mode === "signup" ? "bg-gray-900 text-white" : "bg-white text-gray-700"}`}
          onClick={() => setMode("signup")}
          type="button"
        >
          Signup
        </button>
      </div>

      <form onSubmit={onSubmit} className="space-y-3">
        <label className="block">
          <div className="text-sm text-gray-600">Email</div>
          <input
            className="mt-1 w-full rounded border border-gray-200 p-2"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </label>
        <label className="block">
          <div className="text-sm text-gray-600">Password</div>
          <input
            type="password"
            className="mt-1 w-full rounded border border-gray-200 p-2"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </label>
        <button
          type="submit"
          disabled={loading}
          className="w-full rounded bg-gray-900 px-4 py-2 text-white hover:bg-gray-800 disabled:bg-gray-400"
        >
          {loading ? "Please wait..." : mode === "login" ? "Login" : "Create account"}
        </button>
      </form>
    </div>
  );
}

