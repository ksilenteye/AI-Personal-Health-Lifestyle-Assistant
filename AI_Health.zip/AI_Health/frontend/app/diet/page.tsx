"use client";

export default function DietPage() {
  return (
    <div className="space-y-3">
      <h1 className="text-2xl font-semibold">Diet</h1>
      <div className="text-sm text-gray-600">Phase 2: budget + preferences food recommendations.</div>
    </div>
  );
}

