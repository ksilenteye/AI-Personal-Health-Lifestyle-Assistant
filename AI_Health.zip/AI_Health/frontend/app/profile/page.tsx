"use client";

import { useEffect, useState } from "react";
import ProfileForm from "../../src/components/Forms/ProfileForm";
import { useSessionStore } from "../../src/store/session";
import { getMyProfile, type Profile } from "../../src/services/profile";

export default function ProfilePage() {
  const token = useSessionStore((s) => s.token);
  const hydrate = useSessionStore((s) => s.hydrate);
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  useEffect(() => {
    async function load() {
      setLoading(true);
      setError(null);
      try {
        if (!token) throw new Error("Please login first.");
        const p = await getMyProfile();
        setProfile(p);
      } catch (err: any) {
        setError(err?.message || "Failed to load profile");
      } finally {
        setLoading(false);
      }
    }

    load();
  }, [token]);

  if (loading) return <div>Loading...</div>;
  if (error) return <div className="text-sm text-red-700">{error}</div>;

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Your Profile</h1>
      <ProfileForm initial={profile} />
    </div>
  );
}

