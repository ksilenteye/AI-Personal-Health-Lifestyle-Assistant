import type { Metadata } from "next";
import "./globals.css";
import Navbar from "../src/components/Navbar";
import type { ReactNode } from "react";

export const metadata: Metadata = {
  title: "AI Personal Health & Lifestyle Assistant",
  description: "Phase 1 MVP",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-gray-50 text-gray-900">
        <Navbar />
        <main className="mx-auto max-w-5xl p-4">{children}</main>
      </body>
    </html>
  );
}

