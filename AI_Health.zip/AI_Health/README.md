# AI Personal Health & Lifestyle Assistant

Production-shaped monolith with:
- Backend: FastAPI (JWT auth, SQLAlchemy, PostgreSQL)
- Frontend: Next.js (App Router, Tailwind, Zustand)
- Future AI modules: `/ai`

## Prerequisites
- Docker + Docker Compose

## Run locally (Docker)
1. Create env values (optional):
   - `backend/.env.example` is provided for reference.
2. Start:
   ```bash
   docker compose up --build
   ```
3. Open:
   - Frontend: http://localhost:3000
   - API: http://localhost:8000/docs

## Phase 1 coverage
- Signup/Login (JWT)
- Profile (age, weight, height, gender, goal, body type)
- Daily activity input (steps, calories burned, distance, sleep/wake)
- Dashboard + today recommendations (rule-based, no ML)

